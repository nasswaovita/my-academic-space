document.addEventListener("DOMContentLoaded", () => {
  const search = document.getElementById("course-search");
  const cards = [...document.querySelectorAll(".course-card")];
  const count = document.getElementById("course-count");

  function filterCourses() {
    if (!search) return;
    const query = search.value.trim().toLocaleLowerCase("id");
    let visible = 0;
    cards.forEach(card => {
      const matches = card.textContent.toLocaleLowerCase("id").includes(query);
      card.hidden = !matches;
      if (matches) visible++;
    });
    if (count) count.textContent = `${visible} dari ${cards.length} mata kuliah`;
  }
  if (search) {
    search.addEventListener("input", filterCourses);
    filterCourses();
  }

  document.querySelectorAll(".nav-link").forEach(link => {
    link.addEventListener("click", () => {
      document.querySelectorAll(".nav-link").forEach(item => item.classList.remove("active"));
      link.classList.add("active");
    });
  });
});
